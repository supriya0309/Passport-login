module.exports = {
    MongoURI:'mongodb+srv://EmployeeDB:<employees>@cluster0.emp5l.mongodb.net/<EmployeeDB>?retryWrites=true&w=majority'};